# 3D-Printer-Material-Prediction
![image](https://github.com/Supreetha-02/3D-Printer-Material-Prediction/assets/80637922/9bb09100-ca55-4567-a04c-5e3ba34be30d)
